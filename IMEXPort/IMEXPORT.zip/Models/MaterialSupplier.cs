﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IMEXPort.Models
{
	public class MaterialSupplier

	{
		public int MaterialSupplierID, MaterialID, SupplierID;

	}
}