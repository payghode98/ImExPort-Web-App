﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IMEXPort.Models
{
	public class Material
	{
		public int MaterialID, StaffID;
		public string MaterialName, MaterialCode;

	}
}