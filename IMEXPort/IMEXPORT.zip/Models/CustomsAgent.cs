﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IMEXPort.Models
{
	public class CustomsAgent
	{
		public int  CustomsAgentID;
		public string Mobile, Name, Email, Photo, Username,Port, Password, Country;
		public bool IsActive;
	}
}